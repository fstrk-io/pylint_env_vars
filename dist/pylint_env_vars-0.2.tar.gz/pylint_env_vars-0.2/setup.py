import setuptools
from setuptools import setup

setup(
    name='pylint_env_vars',
    version='0.2',
    description='pylint_env_vars',
    url='https://github.com/fstrk-io/pylint_env_vars',
    author='Mikhail Novikov',
    author_email='mikhail.g.novikov@gmail.com',
    license='MIT',
    packages=setuptools.find_packages(),
)

